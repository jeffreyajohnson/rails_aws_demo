require 'rails_helper'

RSpec.describe SecretsController, :type => :controller do

end

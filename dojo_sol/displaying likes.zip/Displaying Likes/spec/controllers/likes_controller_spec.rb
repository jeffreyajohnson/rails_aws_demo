require 'rails_helper'

RSpec.describe LikesController, :type => :controller do

end

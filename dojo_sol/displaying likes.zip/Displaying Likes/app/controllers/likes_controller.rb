class LikesController < ApplicationController
  
end
